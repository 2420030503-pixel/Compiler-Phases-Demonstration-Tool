import { useState, useMemo } from "react";
import { motion } from "motion/react";
import {
  Hash,
  CheckCircle2,
  GitBranch,
  Layers,
  Zap,
  ChevronRight,
  ChevronLeft,
  Play,
  RotateCcw,
  XCircle,
  Terminal,
  Sparkles,
  Code2,
  ArrowRight,
  BookOpen,
  MousePointerClick,
  BarChart3,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────

type TokType =
  | "KEYWORD"
  | "IDENTIFIER"
  | "INTEGER"
  | "FLOAT"
  | "STRING"
  | "OPERATOR"
  | "ASSIGN"
  | "LPAREN"
  | "RPAREN"
  | "COMMA"
  | "UNKNOWN";

interface Token {
  type: TokType;
  value: string;
  line: number;
  col: number;
  desc: string;
}

type ASTNode =
  | { kind: "assign"; target: string; value: ASTNode }
  | { kind: "binop"; op: string; left: ASTNode; right: ASTNode }
  | { kind: "int"; value: number }
  | { kind: "float"; value: number }
  | { kind: "id"; name: string }
  | { kind: "err"; msg: string };

interface Stmt {
  src: string;
  ast: ASTNode;
  valid: boolean;
  rule: string;
}
interface IRInstr {
  code: string;
  src: string;
}
interface OptLine {
  orig: string;
  opt: string;
  technique: string;
  changed: boolean;
}
interface TNode {
  id: string;
  label: string;
  children: TNode[];
  x: number;
  y: number;
}

// ─── Constants ────────────────────────────────────────────────────

const KW = new Set([
  "if",
  "else",
  "while",
  "for",
  "return",
  "int",
  "float",
  "print",
  "def",
  "and",
  "or",
  "not",
]);

const TOK_DESC: Record<TokType, string> = {
  KEYWORD: "Reserved language keyword",
  IDENTIFIER: "Variable or function name",
  INTEGER: "Integer numeric literal",
  FLOAT: "Floating-point literal",
  STRING: "String literal value",
  OPERATOR: "Arithmetic / relational operator",
  ASSIGN: "Assignment operator",
  LPAREN: "Left parenthesis",
  RPAREN: "Right parenthesis",
  COMMA: "Argument separator",
  UNKNOWN: "Unrecognized symbol",
};

const TOK_STYLE: Record<
  TokType,
  { badge: string; dot: string; glow: string }
> = {
  KEYWORD: {
    badge:
      "text-violet-300 bg-violet-500/15 border-violet-500/30",
    dot: "bg-violet-400",
    glow: "shadow-violet-500/30",
  },
  IDENTIFIER: {
    badge: "text-cyan-300 bg-cyan-500/15 border-cyan-500/30",
    dot: "bg-cyan-400",
    glow: "shadow-cyan-500/30",
  },
  INTEGER: {
    badge:
      "text-emerald-300 bg-emerald-500/15 border-emerald-500/30",
    dot: "bg-emerald-400",
    glow: "shadow-emerald-500/30",
  },
  FLOAT: {
    badge: "text-lime-300 bg-lime-500/15 border-lime-500/30",
    dot: "bg-lime-400",
    glow: "shadow-lime-500/30",
  },
  STRING: {
    badge: "text-amber-300 bg-amber-500/15 border-amber-500/30",
    dot: "bg-amber-400",
    glow: "shadow-amber-500/30",
  },
  OPERATOR: {
    badge:
      "text-orange-300 bg-orange-500/15 border-orange-500/30",
    dot: "bg-orange-400",
    glow: "shadow-orange-500/30",
  },
  ASSIGN: {
    badge: "text-rose-300 bg-rose-500/15 border-rose-500/30",
    dot: "bg-rose-400",
    glow: "shadow-rose-500/30",
  },
  LPAREN: {
    badge: "text-slate-300 bg-slate-500/15 border-slate-500/30",
    dot: "bg-slate-400",
    glow: "",
  },
  RPAREN: {
    badge: "text-slate-300 bg-slate-500/15 border-slate-500/30",
    dot: "bg-slate-400",
    glow: "",
  },
  COMMA: {
    badge: "text-slate-300 bg-slate-500/15 border-slate-500/30",
    dot: "bg-slate-400",
    glow: "",
  },
  UNKNOWN: {
    badge: "text-red-300 bg-red-500/15 border-red-500/30",
    dot: "bg-red-400",
    glow: "shadow-red-500/30",
  },
};

const CFG_RULES = [
  ["program", "statement*"],
  ["statement", "assignment | if-stmt | while-stmt"],
  ["assignment", 'id "=" expr'],
  ["expr", 'term (("+"|"-") term)*'],
  ["term", 'factor (("*"|"/") factor)*'],
  ["factor", 'id | integer | float | "(" expr ")"'],
];

const PHASES = [
  {
    id: "lexical",
    label: "Lexical Analysis",
    short: "01",
    Icon: Hash,
    color: "#2dd4bf",
    glow: "rgba(45,212,191,0.35)",
  },
  {
    id: "syntax",
    label: "Syntax Analysis",
    short: "02",
    Icon: CheckCircle2,
    color: "#86efac",
    glow: "rgba(134,239,172,0.35)",
  },
  {
    id: "parsetree",
    label: "Parse Tree",
    short: "03",
    Icon: GitBranch,
    color: "#60a5fa",
    glow: "rgba(96,165,250,0.35)",
  },
  {
    id: "ir",
    label: "Intermediate Code",
    short: "04",
    Icon: Layers,
    color: "#fbbf24",
    glow: "rgba(251,191,36,0.35)",
  },
  {
    id: "optimize",
    label: "Optimization",
    short: "05",
    Icon: Zap,
    color: "#fb7185",
    glow: "rgba(251,113,133,0.35)",
  },
] as const;

const PHASE_DESC = [
  "The lexer scans source characters and groups them into tokens — the smallest meaningful units such as identifiers, keywords, numbers, and operators.",
  "The parser validates each statement against the Context-Free Grammar, identifying which production rules matched and flagging structural errors.",
  "The parse tree shows how each statement is hierarchically derived from grammar productions. Select a statement to inspect its tree.",
  "Each statement is lowered into Three-Address Code — simplified instructions with at most one operator, using temporaries (t1, t2, …) for sub-results.",
  "The optimizer transforms IR by evaluating constant expressions at compile time (Constant Folding) and substituting known values (Copy Propagation).",
];

const DEFAULT_SRC = `a = 4 + 6
b = a * 2
c = 10 + 0`;

// ─── Lexer ────────────────────────────────────────────────────────

function lex(src: string): Token[] {
  const out: Token[] = [];
  src.split("\n").forEach((line, ln) => {
    const t = line.trim();
    if (!t || t.startsWith("#")) return;
    let i = 0;
    while (i < line.length) {
      if (/\s/.test(line[i])) {
        i++;
        continue;
      }
      const col = i + 1;
      if (/\d/.test(line[i])) {
        let j = i;
        while (j < line.length && /[\d.]/.test(line[j])) j++;
        const v = line.slice(i, j);
        const tp: TokType = v.includes(".")
          ? "FLOAT"
          : "INTEGER";
        out.push({
          type: tp,
          value: v,
          line: ln + 1,
          col,
          desc: TOK_DESC[tp],
        });
        i = j;
        continue;
      }
      if (line[i] === '"' || line[i] === "'") {
        const q = line[i];
        let j = i + 1;
        while (j < line.length && line[j] !== q) j++;
        out.push({
          type: "STRING",
          value: line.slice(i, j + 1),
          line: ln + 1,
          col,
          desc: TOK_DESC.STRING,
        });
        i = j + 1;
        continue;
      }
      if (/[a-zA-Z_]/.test(line[i])) {
        let j = i;
        while (j < line.length && /\w/.test(line[j])) j++;
        const v = line.slice(i, j);
        const tp: TokType = KW.has(v)
          ? "KEYWORD"
          : "IDENTIFIER";
        out.push({
          type: tp,
          value: v,
          line: ln + 1,
          col,
          desc: TOK_DESC[tp],
        });
        i = j;
        continue;
      }
      const two = line.slice(i, i + 2);
      if (["==", "!=", "<=", ">=", "**"].includes(two)) {
        out.push({
          type: "OPERATOR",
          value: two,
          line: ln + 1,
          col,
          desc: TOK_DESC.OPERATOR,
        });
        i += 2;
        continue;
      }
      if (line[i] === "=") {
        out.push({
          type: "ASSIGN",
          value: "=",
          line: ln + 1,
          col,
          desc: TOK_DESC.ASSIGN,
        });
        i++;
        continue;
      }
      if ("+-*/".includes(line[i])) {
        out.push({
          type: "OPERATOR",
          value: line[i],
          line: ln + 1,
          col,
          desc: TOK_DESC.OPERATOR,
        });
        i++;
        continue;
      }
      if (line[i] === "(") {
        out.push({
          type: "LPAREN",
          value: "(",
          line: ln + 1,
          col,
          desc: TOK_DESC.LPAREN,
        });
        i++;
        continue;
      }
      if (line[i] === ")") {
        out.push({
          type: "RPAREN",
          value: ")",
          line: ln + 1,
          col,
          desc: TOK_DESC.RPAREN,
        });
        i++;
        continue;
      }
      if (line[i] === ",") {
        out.push({
          type: "COMMA",
          value: ",",
          line: ln + 1,
          col,
          desc: TOK_DESC.COMMA,
        });
        i++;
        continue;
      }
      out.push({
        type: "UNKNOWN",
        value: line[i],
        line: ln + 1,
        col,
        desc: TOK_DESC.UNKNOWN,
      });
      i++;
    }
  });
  return out;
}

// ─── Parser ───────────────────────────────────────────────────────

function parseExprToks(
  toks: string[],
  p: { i: number },
): ASTNode {
  let left = parseTerm(toks, p);
  while (
    p.i < toks.length &&
    (toks[p.i] === "+" || toks[p.i] === "-")
  ) {
    const op = toks[p.i++];
    left = {
      kind: "binop",
      op,
      left,
      right: parseTerm(toks, p),
    };
  }
  return left;
}
function parseTerm(toks: string[], p: { i: number }): ASTNode {
  let left = parseFactor(toks, p);
  while (
    p.i < toks.length &&
    (toks[p.i] === "*" || toks[p.i] === "/")
  ) {
    const op = toks[p.i++];
    left = {
      kind: "binop",
      op,
      left,
      right: parseFactor(toks, p),
    };
  }
  return left;
}
function parseFactor(
  toks: string[],
  p: { i: number },
): ASTNode {
  if (p.i >= toks.length)
    return { kind: "err", msg: "Unexpected end" };
  const tok = toks[p.i++];
  if (tok === "(") {
    const inner = parseExprToks(toks, p);
    if (p.i < toks.length && toks[p.i] === ")") p.i++;
    return inner;
  }
  if (/^\d+\.\d+$/.test(tok))
    return { kind: "float", value: parseFloat(tok) };
  if (/^\d+$/.test(tok))
    return { kind: "int", value: parseInt(tok) };
  if (/^[a-zA-Z_]\w*$/.test(tok))
    return { kind: "id", name: tok };
  return { kind: "err", msg: `Unexpected: ${tok}` };
}
function parseLine(line: string): Stmt {
  const src = line.trim();
  if (!src || src.startsWith("#"))
    return {
      src,
      ast: { kind: "err", msg: "empty" },
      valid: false,
      rule: "",
    };
  const m = src.match(/^([a-zA-Z_]\w*)\s*=\s*(.+)$/);
  if (m) {
    const [, target, exprStr] = m;
    const toks =
      exprStr.match(/\d+\.\d+|\d+|[a-zA-Z_]\w*|[+\-*/()]/g) ||
      [];
    try {
      const p = { i: 0 };
      const value = parseExprToks(toks, p);
      if (value.kind === "err")
        return {
          src,
          ast: value,
          valid: false,
          rule: "assignment → id '=' expr  ✗ SYNTAX ERROR",
        };
      return {
        src,
        ast: { kind: "assign", target, value },
        valid: true,
        rule: "assignment → id '=' expr",
      };
    } catch {
      return {
        src,
        ast: { kind: "err", msg: "Parse error" },
        valid: false,
        rule: "assignment → id '=' expr  ✗ SYNTAX ERROR",
      };
    }
  }
  return {
    src,
    ast: { kind: "err", msg: "Unrecognized" },
    valid: false,
    rule: "No grammar rule matched",
  };
}

// ─── IR Generation ────────────────────────────────────────────────

function genIR(
  ast: ASTNode,
  temps: { n: number },
  out: IRInstr[],
  src: string,
): string {
  if (ast.kind === "int") return String(ast.value);
  if (ast.kind === "float") return String(ast.value);
  if (ast.kind === "id") return ast.name;
  if (ast.kind === "binop") {
    const l = genIR(ast.left, temps, out, src);
    const r = genIR(ast.right, temps, out, src);
    const t = `t${++temps.n}`;
    out.push({ code: `${t} = ${l} ${ast.op} ${r}`, src });
    return t;
  }
  if (ast.kind === "assign") {
    const r = genIR(ast.value, temps, out, src);
    out.push({ code: `${ast.target} = ${r}`, src });
    return ast.target;
  }
  return "?";
}

// ─── Optimizer ────────────────────────────────────────────────────

function optimize(instrs: IRInstr[]): OptLine[] {
  const vals: Record<string, number> = {};
  return instrs.map(({ code }) => {
    const bin = code.match(
      /^(\w+)\s*=\s*(\w+)\s*([+\-*/])\s*(\w+)$/,
    );
    if (bin) {
      const [, d, lv, op, rv] = bin;
      const l = vals[lv] ?? parseFloat(lv);
      const r = vals[rv] ?? parseFloat(rv);
      if (!isNaN(l) && !isNaN(r)) {
        const res =
          op === "+"
            ? l + r
            : op === "-"
              ? l - r
              : op === "*"
                ? l * r
                : r
                  ? l / r
                  : NaN;
        if (!isNaN(res)) {
          vals[d] = res;
          return {
            orig: code,
            opt: `${d} = ${res}`,
            technique: "Constant Folding",
            changed: true,
          };
        }
      }
      return {
        orig: code,
        opt: code,
        technique: "—",
        changed: false,
      };
    }
    const copy = code.match(/^(\w+)\s*=\s*(\w+)$/);
    if (copy) {
      const [, d, sv] = copy;
      if (vals[sv] !== undefined) {
        vals[d] = vals[sv];
        return {
          orig: code,
          opt: `${d} = ${vals[sv]}`,
          technique: "Copy Propagation",
          changed: true,
        };
      }
      const n = parseFloat(sv);
      if (!isNaN(n)) vals[d] = n;
    }
    return {
      orig: code,
      opt: code,
      technique: "—",
      changed: false,
    };
  });
}

// ─── Tree Layout ──────────────────────────────────────────────────

function buildTree(ast: ASTNode, ids: { n: number }): TNode {
  const id = `n${ids.n++}`;
  if (ast.kind === "int")
    return {
      id,
      label: String(ast.value),
      children: [],
      x: 0,
      y: 0,
    };
  if (ast.kind === "float")
    return {
      id,
      label: String(ast.value),
      children: [],
      x: 0,
      y: 0,
    };
  if (ast.kind === "id")
    return { id, label: ast.name, children: [], x: 0, y: 0 };
  if (ast.kind === "err")
    return { id, label: "?", children: [], x: 0, y: 0 };
  if (ast.kind === "binop")
    return {
      id,
      label: ast.op,
      x: 0,
      y: 0,
      children: [
        buildTree(ast.left, ids),
        buildTree(ast.right, ids),
      ],
    };
  if (ast.kind === "assign")
    return {
      id,
      label: "=",
      x: 0,
      y: 0,
      children: [
        {
          id: `n${ids.n++}`,
          label: ast.target,
          children: [],
          x: 0,
          y: 0,
        },
        buildTree(ast.value, ids),
      ],
    };
  return { id, label: "?", children: [], x: 0, y: 0 };
}
function layoutTree(
  node: TNode,
  depth: number,
  leaf: { n: number },
): void {
  node.y = depth;
  if (!node.children.length) {
    node.x = leaf.n++;
    return;
  }
  for (const c of node.children) layoutTree(c, depth + 1, leaf);
  node.x =
    node.children.reduce((s, c) => s + c.x, 0) /
    node.children.length;
}
function flatTree(node: TNode): TNode[] {
  return [node, ...node.children.flatMap(flatTree)];
}
function treeEdges(
  node: TNode,
): { x1: number; y1: number; x2: number; y2: number }[] {
  return node.children.flatMap((c) => [
    { x1: node.x, y1: node.y, x2: c.x, y2: c.y },
    ...treeEdges(c),
  ]);
}

// ─── Shared UI helpers ────────────────────────────────────────────

function SectionLabel({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <span className="text-[10px] font-mono uppercase tracking-[0.15em] text-muted-foreground">
      {children}
    </span>
  );
}

function Divider() {
  return (
    <div
      className="flex-1 h-px"
      style={{
        background:
          "linear-gradient(to right, rgba(45,212,191,0.18), transparent)",
      }}
    />
  );
}

// ─── Phase Views ──────────────────────────────────────────────────

function LexicalView({ tokens }: { tokens: Token[] }) {
  const usedTypes = [...new Set(tokens.map((t) => t.type))];
  return (
    <div className="flex flex-col gap-4 h-full min-h-0">
      {/* Header row */}
      <div className="flex items-center gap-3">
        <SectionLabel>Token Stream</SectionLabel>
        <Divider />
        <span
          className="text-[10px] font-mono px-2 py-0.5 rounded-full"
          style={{
            background: "rgba(45,212,191,0.12)",
            color: "#5eead4",
          }}
        >
          {tokens.length} tokens
        </span>
      </div>

      {/* Token badge cloud */}
      <div
        className="flex flex-wrap gap-1.5 p-3 rounded-xl min-h-[2.5rem]"
        style={{
          background: "rgba(45,212,191,0.06)",
          border: "1px solid rgba(45,212,191,0.12)",
        }}
      >
        {tokens.map((tok, i) => (
          <motion.span
            key={i}
            initial={{ opacity: 0, scale: 0.5, y: 4 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{
              delay: i * 0.025,
              type: "spring",
              stiffness: 300,
              damping: 20,
            }}
            className={`px-2 py-0.5 rounded-md border text-[11px] font-mono font-medium shadow-sm ${TOK_STYLE[tok.type].badge} ${TOK_STYLE[tok.type].glow}`}
          >
            {tok.value}
          </motion.span>
        ))}
        {tokens.length === 0 && (
          <span className="text-[11px] font-mono text-muted-foreground italic">
            No tokens found.
          </span>
        )}
      </div>

      {/* Table */}
      <div
        className="flex-1 overflow-auto min-h-0 rounded-xl"
        style={{ border: "1px solid rgba(45,212,191,0.1)" }}
      >
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr
              style={{
                background: "rgba(45,212,191,0.07)",
                borderBottom: "1px solid rgba(45,212,191,0.12)",
              }}
            >
              {[
                "#",
                "Lexeme",
                "Token Type",
                "Ln:Col",
                "Description",
              ].map((h) => (
                <th
                  key={h}
                  className="text-left py-2.5 px-3 text-[10px] font-mono uppercase tracking-wider text-muted-foreground"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {tokens.map((tok, i) => (
              <motion.tr
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                style={{
                  borderBottom:
                    "1px solid rgba(45,212,191,0.07)",
                }}
                className="hover:bg-white/[0.02] transition-colors"
              >
                <td className="py-2 px-3 font-mono text-xs text-muted-foreground">
                  {i + 1}
                </td>
                <td className="py-2 px-3 font-mono text-sm font-bold text-foreground">
                  {tok.value}
                </td>
                <td className="py-2 px-3">
                  <span
                    className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md border text-[10px] font-mono ${TOK_STYLE[tok.type].badge}`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${TOK_STYLE[tok.type].dot}`}
                    />
                    {tok.type}
                  </span>
                </td>
                <td className="py-2 px-3 font-mono text-xs text-muted-foreground">
                  {tok.line}:{tok.col}
                </td>
                <td className="py-2 px-3 text-xs text-muted-foreground">
                  {tok.desc}
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Legend */}
      {usedTypes.length > 0 && (
        <div
          className="flex flex-wrap gap-x-4 gap-y-2 pt-2"
          style={{
            borderTop: "1px solid rgba(45,212,191,0.1)",
          }}
        >
          {usedTypes.map((tp) => (
            <span
              key={tp}
              className="flex items-center gap-1.5 text-[10px] font-mono text-muted-foreground"
            >
              <span
                className={`w-2 h-2 rounded-full ${TOK_STYLE[tp].dot}`}
              />
              {tp}{" "}
              <span className="opacity-50">
                ({tokens.filter((t) => t.type === tp).length})
              </span>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function SyntaxView({ stmts }: { stmts: Stmt[] }) {
  return (
    <div className="flex flex-col gap-5 h-full min-h-0 overflow-auto">
      {/* CFG */}
      <div>
        <div className="flex items-center gap-3 mb-3">
          <SectionLabel>Context-Free Grammar</SectionLabel>
          <Divider />
        </div>
        <div
          className="rounded-xl p-4 space-y-2"
          style={{
            background: "rgba(52,211,153,0.04)",
            border: "1px solid rgba(52,211,153,0.12)",
          }}
        >
          {CFG_RULES.map(([rule, expansion], i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex gap-3 font-mono text-sm"
            >
              <span
                className="w-28 shrink-0 font-semibold"
                style={{ color: "#6ee7b7" }}
              >
                {rule}
              </span>
              <span className="shrink-0 text-muted-foreground">
                →
              </span>
              <span style={{ color: "rgba(212,240,232,0.72)" }}>
                {expansion}
              </span>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Validation */}
      <div>
        <div className="flex items-center gap-3 mb-3">
          <SectionLabel>Validation Results</SectionLabel>
          <Divider />
          <span
            className="text-[10px] font-mono px-2 py-0.5 rounded-full"
            style={{
              background: "rgba(52,211,153,0.12)",
              color: "#6ee7b7",
            }}
          >
            {stmts.filter((s) => s.valid).length}/{stmts.length}{" "}
            valid
          </span>
        </div>
        <div className="space-y-2">
          {stmts.map((stmt, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className="rounded-xl p-3.5 flex items-start gap-3"
              style={
                stmt.valid
                  ? {
                      background: "rgba(52,211,153,0.06)",
                      border: "1px solid rgba(52,211,153,0.2)",
                    }
                  : {
                      background: "rgba(248,113,113,0.06)",
                      border: "1px solid rgba(248,113,113,0.2)",
                    }
              }
            >
              {stmt.valid ? (
                <CheckCircle2
                  className="w-4 h-4 mt-0.5 shrink-0"
                  style={{ color: "#34d399" }}
                />
              ) : (
                <XCircle
                  className="w-4 h-4 mt-0.5 shrink-0"
                  style={{ color: "#f87171" }}
                />
              )}
              <div className="flex-1 min-w-0">
                <div className="font-mono text-sm text-foreground">
                  {stmt.src}
                </div>
                <div
                  className="text-[11px] mt-1 font-mono opacity-60"
                  style={{
                    color: stmt.valid ? "#34d399" : "#f87171",
                  }}
                >
                  {stmt.rule}
                </div>
              </div>
              <span
                className="text-[10px] font-mono px-2 py-0.5 rounded-md shrink-0 font-semibold"
                style={
                  stmt.valid
                    ? {
                        background: "rgba(52,211,153,0.15)",
                        color: "#6ee7b7",
                      }
                    : {
                        background: "rgba(248,113,113,0.15)",
                        color: "#fca5a5",
                      }
                }
              >
                {stmt.valid ? "VALID" : "ERROR"}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ParseTreeView({
  stmts,
  treeIdx,
  setTreeIdx,
}: {
  stmts: Stmt[];
  treeIdx: number;
  setTreeIdx: (n: number) => void;
}) {
  const valid = stmts.filter((s) => s.valid);
  const idx = Math.min(treeIdx, valid.length - 1);
  const stmt = valid[idx];

  const { nodes, edges } = useMemo(() => {
    if (!stmt)
      return {
        nodes: [] as TNode[],
        edges: [] as ReturnType<typeof treeEdges>,
      };
    const ids = { n: 0 };
    const root = buildTree(stmt.ast, ids);
    layoutTree(root, 0, { n: 0 });
    return { nodes: flatTree(root), edges: treeEdges(root) };
  }, [stmt]);

  if (!stmt)
    return (
      <div className="flex items-center justify-center h-full text-sm font-mono text-muted-foreground">
        No valid statements to visualize.
      </div>
    );

  const XS = 80,
    YS = 90,
    PAD = 56,
    NR = 24;
  const maxX = Math.max(...nodes.map((n) => n.x), 0);
  const maxY = Math.max(...nodes.map((n) => n.y), 0);
  const W = (maxX + 1) * XS + PAD * 2;
  const H = (maxY + 1) * YS + PAD * 2;
  const px = (x: number) => PAD + x * XS;
  const py = (y: number) => PAD + y * YS;

  const OP_COLOR: Record<
    string,
    { fill: string; stroke: string; text: string }
  > = {
    "=": {
      fill: "#061a18",
      stroke: "#2dd4bf",
      text: "#5eead4",
    },
    "+": {
      fill: "#1a2e0a",
      stroke: "#65a30d",
      text: "#bef264",
    },
    "-": {
      fill: "#1a2e0a",
      stroke: "#65a30d",
      text: "#bef264",
    },
    "*": {
      fill: "#1a1a2e",
      stroke: "#1d4ed8",
      text: "#93c5fd",
    },
    "/": {
      fill: "#1a1a2e",
      stroke: "#1d4ed8",
      text: "#93c5fd",
    },
  };

  return (
    <div className="flex flex-col gap-3 h-full min-h-0">
      {valid.length > 1 && (
        <div className="flex gap-2 flex-wrap">
          {valid.map((s, i) => (
            <button
              key={i}
              onClick={() => setTreeIdx(i)}
              className="px-3 py-1.5 rounded-lg text-[11px] font-mono transition-all"
              style={
                idx === i
                  ? {
                      background: "rgba(96,165,250,0.14)",
                      border: "1px solid rgba(96,165,250,0.45)",
                      color: "#93c5fd",
                    }
                  : {
                      background: "transparent",
                      border: "1px solid rgba(45,212,191,0.12)",
                      color: "#4a8a7a",
                    }
              }
            >
              {s.src}
            </button>
          ))}
        </div>
      )}

      <div
        className="flex-1 overflow-auto flex items-center justify-center min-h-[220px] rounded-xl"
        style={{
          background:
            "radial-gradient(ellipse at 50% 40%, rgba(96,165,250,0.06) 0%, transparent 70%)",
          border: "1px solid rgba(96,165,250,0.1)",
        }}
      >
        <svg
          width={W}
          height={H}
          style={{ overflow: "visible" }}
        >
          <defs>
            <filter id="nodeGlow">
              <feGaussianBlur stdDeviation="5" result="b" />
              <feMerge>
                <feMergeNode in="b" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            <filter id="leafGlow">
              <feGaussianBlur stdDeviation="3" result="b" />
              <feMerge>
                <feMergeNode in="b" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            <linearGradient
              id="edgeGrad"
              x1="0%"
              y1="0%"
              x2="0%"
              y2="100%"
            >
              <stop
                offset="0%"
                stopColor="rgba(45,212,191,0.4)"
              />
              <stop
                offset="100%"
                stopColor="rgba(96,165,250,0.35)"
              />
            </linearGradient>
          </defs>

          {edges.map((e, i) => (
            <motion.line
              key={i}
              x1={px(e.x1)}
              y1={py(e.y1)}
              x2={px(e.x2)}
              y2={py(e.y2)}
              stroke="url(#edgeGrad)"
              strokeWidth={1.5}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: i * 0.04 }}
            />
          ))}

          {nodes.map((n, i) => {
            const isOp = /^[=+\-*/]$/.test(n.label);
            const col = OP_COLOR[n.label] ?? {
              fill: "#061210",
              stroke: "#2dd4bf",
              text: "#5eead4",
            };
            return (
              <motion.g
                key={n.id}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{
                  delay: i * 0.05,
                  type: "spring",
                  stiffness: 240,
                  damping: 18,
                }}
                style={{
                  transformOrigin: `${px(n.x)}px ${py(n.y)}px`,
                }}
              >
                <circle
                  cx={px(n.x)}
                  cy={py(n.y)}
                  r={NR}
                  fill={col.fill}
                  stroke={col.stroke}
                  strokeWidth={1.5}
                  filter={
                    isOp ? "url(#nodeGlow)" : "url(#leafGlow)"
                  }
                />
                <text
                  x={px(n.x)}
                  y={py(n.y) + 5}
                  textAnchor="middle"
                  fill={col.text}
                  fontSize={12}
                  fontFamily="JetBrains Mono, monospace"
                  fontWeight="700"
                >
                  {n.label}
                </text>
              </motion.g>
            );
          })}
        </svg>
      </div>

      <div className="text-center text-[11px] font-mono text-muted-foreground">
        Parse tree for:{" "}
        <span style={{ color: "#93c5fd" }}>{stmt.src}</span>
      </div>
    </div>
  );
}

function IRView({ instrs }: { instrs: IRInstr[] }) {
  const srcs = [...new Set(instrs.map((i) => i.src))];
  return (
    <div className="flex flex-col gap-4 h-full min-h-0">
      <div className="flex items-center gap-3">
        <SectionLabel>Three-Address Code</SectionLabel>
        <Divider />
        <span
          className="text-[10px] font-mono px-2 py-0.5 rounded-full"
          style={{
            background: "rgba(251,146,60,0.12)",
            color: "#fb923c",
          }}
        >
          {instrs.length} instructions
        </span>
      </div>
      <div className="flex-1 overflow-auto min-h-0 space-y-3">
        {srcs.map((src, gi) => {
          const group = instrs.filter((i) => i.src === src);
          if (!group.length) return null;
          return (
            <motion.div
              key={src}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: gi * 0.08 }}
              className="rounded-xl overflow-hidden"
              style={{
                border: "1px solid rgba(251,146,60,0.15)",
              }}
            >
              <div
                className="px-4 py-2.5 flex items-center gap-2"
                style={{
                  background: "rgba(251,146,60,0.08)",
                  borderBottom:
                    "1px solid rgba(251,146,60,0.12)",
                }}
              >
                <Code2
                  className="w-3 h-3"
                  style={{ color: "#fb923c" }}
                />
                <span className="text-[10px] font-mono text-muted-foreground">
                  Source:
                </span>
                <span className="text-[11px] font-mono text-foreground font-medium">
                  {src}
                </span>
              </div>
              <div
                className="p-4 space-y-2"
                style={{ background: "rgba(251,146,60,0.03)" }}
              >
                {group.map((ins, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: gi * 0.08 + i * 0.04 }}
                    className="flex items-center gap-3"
                  >
                    <span
                      className="font-mono text-[10px] w-5 text-right shrink-0"
                      style={{ color: "rgba(251,146,60,0.4)" }}
                    >
                      {i + 1}.
                    </span>
                    <span
                      className="font-mono text-sm"
                      style={{ color: "#fed7aa" }}
                    >
                      {ins.code}
                    </span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          );
        })}
      </div>
      <div
        className="rounded-xl p-3 text-[11px] font-mono text-muted-foreground"
        style={{
          background: "rgba(251,146,60,0.05)",
          border: "1px solid rgba(251,146,60,0.1)",
        }}
      >
        <span style={{ color: "#fb923c" }}>Note:</span>{" "}
        Temporaries (t1, t2, …) hold sub-expression results.
        Each instruction has at most one operator.
      </div>
    </div>
  );
}

function OptView({ lines }: { lines: OptLine[] }) {
  const changed = lines.filter((l) => l.changed).length;
  const stats = [
    {
      label: "Total",
      value: lines.length,
      color: "#d4f0e8",
      bg: "rgba(45,212,191,0.1)",
      border: "rgba(45,212,191,0.18)",
    },
    {
      label: "Optimized",
      value: changed,
      color: "#6ee7b7",
      bg: "rgba(52,211,153,0.1)",
      border: "rgba(52,211,153,0.2)",
    },
    {
      label: "Unchanged",
      value: lines.length - changed,
      color: "#4a8a7a",
      bg: "rgba(45,212,191,0.05)",
      border: "rgba(45,212,191,0.1)",
    },
  ];
  return (
    <div className="flex flex-col gap-4 h-full min-h-0">
      <div className="flex items-center gap-3">
        <SectionLabel>Optimization Pass</SectionLabel>
        <Divider />
        <span
          className="text-[10px] font-mono px-2 py-0.5 rounded-full"
          style={{
            background: "rgba(244,114,182,0.12)",
            color: "#f9a8d4",
          }}
        >
          {changed} optimized
        </span>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-3 gap-3 shrink-0">
        {stats.map((s) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="rounded-xl p-3.5 text-center"
            style={{
              background: s.bg,
              border: `1px solid ${s.border}`,
            }}
          >
            <div
              className="text-2xl font-mono font-bold"
              style={{ color: s.color }}
            >
              {s.value}
            </div>
            <div className="text-[10px] font-mono text-muted-foreground mt-1">
              {s.label}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Table */}
      <div
        className="flex-1 overflow-auto min-h-0 rounded-xl"
        style={{ border: "1px solid rgba(244,114,182,0.1)" }}
      >
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr
              style={{
                background: "rgba(244,114,182,0.06)",
                borderBottom:
                  "1px solid rgba(244,114,182,0.12)",
              }}
            >
              {[
                "Original Instruction",
                "Optimized",
                "Technique",
              ].map((h) => (
                <th
                  key={h}
                  className="text-left py-2.5 px-3 text-[10px] font-mono uppercase tracking-wider text-muted-foreground"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {lines.map((l, i) => (
              <motion.tr
                key={i}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.03 }}
                style={{
                  borderBottom:
                    "1px solid rgba(244,114,182,0.07)",
                  background: l.changed
                    ? "rgba(52,211,153,0.04)"
                    : "transparent",
                }}
              >
                <td
                  className={`py-2 px-3 font-mono text-xs ${l.changed ? "line-through opacity-50" : "text-foreground"}`}
                >
                  {l.orig}
                </td>
                <td
                  className="py-2 px-3 font-mono text-xs font-semibold"
                  style={{
                    color: l.changed ? "#6ee7b7" : "#d4f0e8",
                  }}
                >
                  {l.opt}
                </td>
                <td className="py-2 px-3">
                  {l.changed ? (
                    <span
                      className="text-[10px] font-mono px-2 py-0.5 rounded-md font-medium"
                      style={{
                        background: "rgba(52,211,153,0.12)",
                        border:
                          "1px solid rgba(52,211,153,0.25)",
                        color: "#6ee7b7",
                      }}
                    >
                      {l.technique}
                    </span>
                  ) : (
                    <span className="text-[10px] text-muted-foreground font-mono">
                      —
                    </span>
                  )}
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      <div
        className="rounded-xl p-3 text-[11px] font-mono text-muted-foreground shrink-0"
        style={{
          background: "rgba(244,114,182,0.05)",
          border: "1px solid rgba(244,114,182,0.1)",
        }}
      >
        <span style={{ color: "#f9a8d4" }}>
          Techniques applied:
        </span>{" "}
        Constant Folding · Copy Propagation
      </div>

      {/* Final optimized code output */}
      <div
        className="rounded-xl overflow-hidden shrink-0"
        style={{ border: "1px solid rgba(45,212,191,0.2)" }}
      >
        <div
          className="flex items-center justify-between px-4 py-2.5"
          style={{
            background: "rgba(45,212,191,0.08)",
            borderBottom: "1px solid rgba(45,212,191,0.12)",
          }}
        >
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              <div
                className="w-2.5 h-2.5 rounded-full"
                style={{ background: "rgba(248,113,113,0.6)" }}
              />
              <div
                className="w-2.5 h-2.5 rounded-full"
                style={{ background: "rgba(251,191,36,0.6)" }}
              />
              <div
                className="w-2.5 h-2.5 rounded-full"
                style={{ background: "rgba(52,211,153,0.6)" }}
              />
            </div>
            <span
              className="text-[10px] font-mono ml-1"
              style={{ color: "#4a8a7a" }}
            >
              optimized_output.ir
            </span>
          </div>
          <span
            className="text-[10px] font-mono px-2 py-0.5 rounded-full"
            style={{
              background: "rgba(45,212,191,0.1)",
              color: "#5eead4",
            }}
          >
            Final Code
          </span>
        </div>
        <div
          className="p-4 space-y-1"
          style={{ background: "#060e0c" }}
        >
          {lines.map((l, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.04 }}
              className="flex items-center gap-3"
            >
              <span
                className="text-[10px] font-mono w-5 text-right shrink-0"
                style={{ color: "rgba(45,212,191,0.3)" }}
              >
                {i + 1}
              </span>
              <span
                className="font-mono text-sm"
                style={{
                  color: l.changed ? "#5eead4" : "#a7f3d0",
                }}
              >
                {l.opt}
              </span>
              {l.changed && (
                <span
                  className="text-[9px] font-mono ml-auto shrink-0 px-1.5 py-0.5 rounded"
                  style={{
                    background: "rgba(52,211,153,0.1)",
                    color: "#34d399",
                  }}
                >
                  ✓ {l.technique}
                </span>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────

export default function App() {
  const [src, setSrc] = useState(DEFAULT_SRC);
  const [active, setActive] = useState(false);
  const [phase, setPhase] = useState(0);
  const [treeIdx, setTreeIdx] = useState(0);

  const tokens = useMemo(() => lex(src), [src]);
  const stmts = useMemo(
    () =>
      src
        .split("\n")
        .filter((l) => l.trim() && !l.trim().startsWith("#"))
        .map(parseLine),
    [src],
  );
  const irInstrs = useMemo(() => {
    const out: IRInstr[] = [];
    const temps = { n: 0 };
    for (const s of stmts)
      if (s.valid) genIR(s.ast, temps, out, s.src);
    return out;
  }, [stmts]);
  const optLines = useMemo(
    () => optimize(irInstrs),
    [irInstrs],
  );
  const validCount = stmts.filter((s) => s.valid).length;

  function handleAnalyze() {
    setActive(true);
    setPhase(0);
    setTreeIdx(0);
  }
  function handleReset() {
    setSrc(DEFAULT_SRC);
    setActive(false);
    setPhase(0);
  }
  function prevPhase() {
    if (phase > 0) setPhase((p) => p - 1);
  }
  function nextPhase() {
    if (phase < 4) setPhase((p) => p + 1);
  }

  const curPhase = PHASES[phase];

  const BG = `
    radial-gradient(ellipse at 8% 25%, rgba(13,148,136,0.22) 0%, transparent 50%),
    radial-gradient(ellipse at 90% 10%, rgba(251,191,36,0.1) 0%, transparent 45%),
    radial-gradient(ellipse at 58% 90%, rgba(96,165,250,0.1) 0%, transparent 50%),
    #04080e
  `;

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        fontFamily: "Plus Jakarta Sans, sans-serif",
        background: BG,
        color: "#d4f0e8",
      }}
    >
      {/* ════════════════════════════ HEADER ════════════════════════════ */}
      <header
        style={{
          borderBottom: "1px solid rgba(45,212,191,0.1)",
          background: "rgba(4,8,14,0.9)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)",
          position: "sticky",
          top: 0,
          zIndex: 30,
        }}
      >
        <div className="max-w-[1400px] mx-auto px-6 py-3.5 flex items-center justify-between gap-4">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
              style={{
                background:
                  "linear-gradient(135deg,#0d9488,#fbbf24)",
                boxShadow: "0 0 16px rgba(13,148,136,0.5)",
              }}
            >
              <Terminal className="w-4 h-4 text-white" />
            </div>
            <div>
              <div
                style={{
                  fontFamily: "Rajdhani,sans-serif",
                  fontSize: 17,
                  fontWeight: 700,
                  lineHeight: 1,
                }}
              >
                <span
                  style={{
                    background:
                      "linear-gradient(90deg,#2dd4bf,#fbbf24)",
                    WebkitBackgroundClip: "text",
                    backgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    color: "transparent",
                  }}
                >
                  Compiler Phases
                </span>
                <span
                  style={{
                    color: "rgba(212,240,232,0.25)",
                    marginLeft: 6,
                    fontWeight: 400,
                    fontSize: 14,
                  }}
                >
                  Demo
                </span>
              </div>
              <div
                className="text-[10px] font-mono"
                style={{ color: "#3a6a60", marginTop: 1 }}
              >
                Interactive Compiler Visualization
              </div>
            </div>
          </div>

          {/* Phase tabs — shown when active on desktop */}
          {active && (
            <div
              className="hidden lg:flex items-center gap-px p-1 rounded-xl"
              style={{
                background: "rgba(45,212,191,0.05)",
                border: "1px solid rgba(45,212,191,0.1)",
              }}
            >
              {PHASES.map((p, i) => {
                const { Icon } = p;
                const isCurrent = i === phase;
                return (
                  <button
                    key={p.id}
                    onClick={() => setPhase(i)}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-[11px] font-mono transition-all"
                    style={
                      isCurrent
                        ? {
                            background: `rgba(${hexToRgb(p.color)},0.15)`,
                            color: p.color,
                            boxShadow: `0 0 10px ${p.glow}`,
                          }
                        : { color: "#4a8a7a" }
                    }
                  >
                    <Icon className="w-3 h-3" />
                    <span className="hidden xl:inline">
                      {p.label}
                    </span>
                    <span className="xl:hidden font-bold opacity-50">
                      {p.short}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Right side */}
          <div className="flex items-center gap-3">
            {active && (
              <button
                onClick={handleReset}
                className="hidden sm:flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded-lg transition-all"
                style={{
                  background: "rgba(45,212,191,0.06)",
                  border: "1px solid rgba(45,212,191,0.12)",
                  color: "#4a8a7a",
                }}
              >
                <RotateCcw className="w-3 h-3" /> Reset
              </button>
            )}
            <div className="flex items-center gap-2">
              <span
                className="w-1.5 h-1.5 rounded-full animate-pulse"
                style={{ background: "#2dd4bf" }}
              />
              <span
                className="text-[10px] font-mono hidden sm:block"
                style={{ color: "#3a6a60" }}
              >
                {active ? `Phase ${phase + 1}/5` : "Ready"}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* ════════════════════════ LANDING HERO ══════════════════════════ */}
      {!active && (
        <section className="w-full max-w-[1400px] mx-auto px-6 pt-14 pb-10 text-center">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-[11px] font-mono mb-6"
            style={{
              background: "rgba(45,212,191,0.08)",
              border: "1px solid rgba(45,212,191,0.18)",
              color: "#5eead4",
            }}
          >
            <Sparkles className="w-3 h-3" /> CSE · Compiler
            Design · Educational Tool
          </motion.div>

          {/* Main heading */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
          >
            <h1
              style={{
                fontFamily: "Rajdhani,sans-serif",
                fontWeight: 700,
                margin: 0,
                lineHeight: 1,
              }}
            >
              <span
                style={{
                  display: "block",
                  fontSize: "clamp(40px,7vw,68px)",
                  background:
                    "linear-gradient(135deg,#2dd4bf 20%,#fbbf24 80%)",
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  color: "transparent",
                }}
              >
                Interactive Compiler
              </span>
              <span
                style={{
                  display: "block",
                  fontSize: "clamp(28px,5vw,46px)",
                  color: "rgba(212,240,232,0.45)",
                  fontWeight: 500,
                  marginTop: 4,
                }}
              >
                Phases Visualization
              </span>
            </h1>
          </motion.div>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="text-base mt-5 mx-auto leading-relaxed"
            style={{ color: "#4a8a7a", maxWidth: 520 }}
          >
            Enter source code and walk through each compilation
            phase — from raw characters to optimized
            machine-level instructions — all visualized step by
            step.
          </motion.p>

          {/* Phase flow */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="flex items-center justify-center flex-wrap gap-2 mt-10"
          >
            {PHASES.map((p, i) => {
              const { Icon } = p;
              return (
                <div
                  key={p.id}
                  className="flex items-center gap-2"
                >
                  <div
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-mono font-medium"
                    style={{
                      background: `rgba(${hexToRgb(p.color)},0.1)`,
                      border: `1px solid rgba(${hexToRgb(p.color)},0.22)`,
                      color: p.color,
                    }}
                  >
                    <span
                      style={{
                        fontSize: 10,
                        opacity: 0.6,
                        fontWeight: 700,
                      }}
                    >
                      {p.short}
                    </span>
                    <Icon className="w-3.5 h-3.5" />
                    {p.label}
                  </div>
                  {i < PHASES.length - 1 && (
                    <ArrowRight
                      className="w-3.5 h-3.5 shrink-0"
                      style={{ color: "rgba(45,212,191,0.25)" }}
                    />
                  )}
                </div>
              );
            })}
          </motion.div>
        </section>
      )}

      {/* ════════════════════ ACTIVE PHASE STEPPER (mobile) ═════════════ */}
      {active && (
        <div
          style={{
            borderBottom: "1px solid rgba(45,212,191,0.08)",
            background: "rgba(4,8,14,0.8)",
            backdropFilter: "blur(12px)",
            position: "sticky",
            top: "57px",
            zIndex: 20,
          }}
        >
          <div className="max-w-[1400px] mx-auto px-4 py-2 overflow-x-auto">
            <div className="flex items-center gap-1 min-w-max lg:hidden">
              {PHASES.map((p, i) => {
                const { Icon } = p;
                const isCurrent = i === phase;
                return (
                  <button
                    key={p.id}
                    onClick={() => setPhase(i)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-mono whitespace-nowrap transition-all"
                    style={
                      isCurrent
                        ? {
                            background: `rgba(${hexToRgb(p.color)},0.12)`,
                            border: `1px solid rgba(${hexToRgb(p.color)},0.3)`,
                            color: p.color,
                          }
                        : { color: "#3a6a60" }
                    }
                  >
                    <Icon className="w-3 h-3" /> {p.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════ MAIN TOOL ═══════════════════════════ */}
      <main
        className="flex-1 max-w-[1400px] mx-auto w-full px-4 md:px-6 pb-10"
        style={{ paddingTop: active ? 24 : 0 }}
      >
        <div
          className={`grid gap-6 ${active ? "lg:grid-cols-[380px_1fr]" : "lg:grid-cols-2 max-w-5xl mx-auto"}`}
        >
          {/* ── LEFT: Code Input ── */}
          <div className="flex flex-col gap-4">
            {/* Code editor card */}
            <div
              style={{
                background:
                  "linear-gradient(135deg,rgba(45,212,191,0.2),rgba(251,191,36,0.12))",
                borderRadius: 14,
                padding: 1,
              }}
            >
              <div
                className="rounded-[13px] overflow-hidden"
                style={{ background: "#060e0c" }}
              >
                {/* Titlebar */}
                <div
                  className="flex items-center justify-between px-4 py-2.5"
                  style={{
                    borderBottom:
                      "1px solid rgba(45,212,191,0.1)",
                    background: "rgba(45,212,191,0.05)",
                  }}
                >
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1.5">
                      <div
                        className="w-2.5 h-2.5 rounded-full"
                        style={{
                          background: "rgba(248,113,113,0.7)",
                        }}
                      />
                      <div
                        className="w-2.5 h-2.5 rounded-full"
                        style={{
                          background: "rgba(251,191,36,0.7)",
                        }}
                      />
                      <div
                        className="w-2.5 h-2.5 rounded-full"
                        style={{
                          background: "rgba(52,211,153,0.7)",
                        }}
                      />
                    </div>
                    <span
                      className="text-[10px] font-mono ml-1"
                      style={{ color: "#3a6a60" }}
                    >
                      source.py
                    </span>
                  </div>
                  <span
                    className="text-[10px] font-mono"
                    style={{ color: "rgba(45,212,191,0.35)" }}
                  >
                    Python
                  </span>
                </div>
                {/* Textarea */}
                <textarea
                  value={src}
                  onChange={(e) => {
                    setSrc(e.target.value);
                    setActive(false);
                  }}
                  spellCheck={false}
                  className="w-full bg-transparent text-sm p-4 resize-none outline-none leading-[1.8]"
                  style={{
                    fontFamily: "JetBrains Mono,monospace",
                    color: "#a7f3d0",
                    caretColor: "#2dd4bf",
                    minHeight: active ? 150 : 130,
                  }}
                  placeholder="Enter source code…"
                />
              </div>
            </div>

            {/* Analyze button */}
            <button
              onClick={handleAnalyze}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl text-white text-sm font-semibold transition-all active:scale-[.98] hover:opacity-95"
              style={{
                background:
                  "linear-gradient(135deg,#0d9488,#fbbf24)",
                boxShadow:
                  "0 4px 24px rgba(13,148,136,0.4), inset 0 1px 0 rgba(255,255,255,0.12)",
              }}
            >
              <Play className="w-4 h-4" />
              {active ? "Re-analyze" : "Analyze Code"}
            </button>

            {/* Active: Phase description */}
            {active && (
              <motion.div
                key={phase}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-xl p-4"
                style={{
                  background: `rgba(${hexToRgb(curPhase.color)},0.06)`,
                  border: `1px solid rgba(${hexToRgb(curPhase.color)},0.18)`,
                }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <curPhase.Icon
                    className="w-3.5 h-3.5"
                    style={{ color: curPhase.color }}
                  />
                  <span
                    className="text-[10px] font-mono font-semibold uppercase tracking-widest"
                    style={{ color: curPhase.color }}
                  >
                    Phase {phase + 1} of {PHASES.length} ·{" "}
                    {curPhase.label}
                  </span>
                </div>
                <p
                  className="text-sm leading-relaxed"
                  style={{ color: "rgba(212,240,232,0.6)" }}
                >
                  {PHASE_DESC[phase]}
                </p>
              </motion.div>
            )}

            {/* Active: Stats */}
            {active && (
              <div className="grid grid-cols-2 gap-2">
                {[
                  {
                    label: "Tokens",
                    value: tokens.length,
                    color: "#2dd4bf",
                    bg: "rgba(45,212,191,0.08)",
                  },
                  {
                    label: "Statements",
                    value: stmts.length,
                    color: "#d4f0e8",
                    bg: "rgba(45,212,191,0.04)",
                  },
                  {
                    label: "Valid",
                    value: validCount,
                    color: "#86efac",
                    bg: "rgba(134,239,172,0.07)",
                  },
                  {
                    label: "IR Instrs",
                    value: irInstrs.length,
                    color: "#fbbf24",
                    bg: "rgba(251,191,36,0.07)",
                  },
                ].map((s) => (
                  <div
                    key={s.label}
                    className="rounded-xl px-3 py-2.5 flex items-center justify-between"
                    style={{
                      background: s.bg,
                      border: "1px solid rgba(45,212,191,0.08)",
                    }}
                  >
                    <span
                      className="text-[10px] font-mono"
                      style={{ color: "#4a8a7a" }}
                    >
                      {s.label}
                    </span>
                    <span
                      className="text-base font-mono font-bold"
                      style={{ color: s.color }}
                    >
                      {s.value}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Landing: How it works */}
            {!active && (
              <div
                className="rounded-xl overflow-hidden mt-1"
                style={{
                  border: "1px solid rgba(45,212,191,0.1)",
                }}
              >
                <div
                  className="px-4 py-2.5 flex items-center gap-2"
                  style={{
                    background: "rgba(45,212,191,0.06)",
                    borderBottom:
                      "1px solid rgba(45,212,191,0.08)",
                  }}
                >
                  <BookOpen
                    className="w-3.5 h-3.5"
                    style={{ color: "#2dd4bf" }}
                  />
                  <span
                    className="text-[11px] font-mono font-semibold"
                    style={{ color: "#5eead4" }}
                  >
                    How it works
                  </span>
                </div>
                <div
                  className="p-4 space-y-3"
                  style={{
                    background: "rgba(45,212,191,0.02)",
                  }}
                >
                  {[
                    {
                      Icon: Code2,
                      color: "#2dd4bf",
                      title: "Write source code",
                      desc: "Enter any simple arithmetic assignment expression in the editor above.",
                    },
                    {
                      Icon: MousePointerClick,
                      color: "#fbbf24",
                      title: "Click Analyze",
                      desc: "The tool processes your code through all 5 compiler phases instantly.",
                    },
                    {
                      Icon: BarChart3,
                      color: "#86efac",
                      title: "Explore each phase",
                      desc: "Navigate between phases to see tokens, parse trees, IR, and optimizations.",
                    },
                  ].map(({ Icon, color, title, desc }) => (
                    <div
                      key={title}
                      className="flex items-start gap-3"
                    >
                      <div
                        className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                        style={{
                          background: `rgba(${hexToRgb(color)},0.12)`,
                        }}
                      >
                        <Icon
                          className="w-3.5 h-3.5"
                          style={{ color }}
                        />
                      </div>
                      <div>
                        <div
                          className="text-xs font-semibold"
                          style={{ color: "#d4f0e8" }}
                        >
                          {title}
                        </div>
                        <div
                          className="text-[11px] mt-0.5 leading-relaxed"
                          style={{ color: "#4a8a7a" }}
                        >
                          {desc}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* ── RIGHT: Phase output or Welcome ── */}
          {active ? (
            /* Phase visualization panel */
            <div
              style={{
                background: `linear-gradient(140deg,rgba(${hexToRgb(curPhase.color)},0.28),rgba(45,212,191,0.08),rgba(251,191,36,0.1))`,
                borderRadius: 16,
                padding: 1,
                boxShadow: `0 0 50px rgba(${hexToRgb(curPhase.color)},0.1)`,
              }}
            >
              <div
                className="rounded-[15px] flex flex-col overflow-hidden"
                style={{
                  background: "#060e0c",
                  minHeight: 560,
                }}
              >
                {/* Panel header */}
                <div
                  className="flex items-center justify-between px-5 py-4 shrink-0"
                  style={{
                    borderBottom: `1px solid rgba(${hexToRgb(curPhase.color)},0.12)`,
                    background: `rgba(${hexToRgb(curPhase.color)},0.04)`,
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center"
                      style={{
                        background: `rgba(${hexToRgb(curPhase.color)},0.15)`,
                        boxShadow: `0 0 14px ${curPhase.glow}`,
                      }}
                    >
                      <curPhase.Icon
                        className="w-4.5 h-4.5"
                        style={{ color: curPhase.color }}
                      />
                    </div>
                    <div>
                      <div
                        className="text-sm font-semibold"
                        style={{ color: "#d4f0e8" }}
                      >
                        {curPhase.label}
                      </div>
                      <div
                        className="text-[10px] font-mono"
                        style={{
                          color: "rgba(45,212,191,0.4)",
                        }}
                      >
                        Phase {phase + 1} of {PHASES.length}
                      </div>
                    </div>
                  </div>
                  {/* Dot indicators */}
                  <div className="flex items-center gap-2">
                    {PHASES.map((p, i) => (
                      <button
                        key={i}
                        onClick={() => setPhase(i)}
                        title={p.label}
                        className="rounded-full transition-all hover:scale-125"
                        style={
                          i === phase
                            ? {
                                width: 22,
                                height: 6,
                                background: curPhase.color,
                                boxShadow: `0 0 8px ${curPhase.glow}`,
                              }
                            : {
                                width: 6,
                                height: 6,
                                background:
                                  "rgba(45,212,191,0.15)",
                              }
                        }
                      />
                    ))}
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 p-5 overflow-hidden flex flex-col min-h-0">
                  <motion.div
                    key={phase}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex-1 min-h-0 flex flex-col"
                  >
                    {phase === 0 && (
                      <LexicalView tokens={tokens} />
                    )}
                    {phase === 1 && (
                      <SyntaxView stmts={stmts} />
                    )}
                    {phase === 2 && (
                      <ParseTreeView
                        stmts={stmts}
                        treeIdx={treeIdx}
                        setTreeIdx={setTreeIdx}
                      />
                    )}
                    {phase === 3 && (
                      <IRView instrs={irInstrs} />
                    )}
                    {phase === 4 && (
                      <OptView lines={optLines} />
                    )}
                  </motion.div>
                </div>

                {/* Navigation bar */}
                <div
                  className="px-5 py-3.5 flex items-center gap-3 shrink-0"
                  style={{
                    borderTop:
                      "1px solid rgba(45,212,191,0.08)",
                  }}
                >
                  <button
                    onClick={prevPhase}
                    disabled={phase === 0}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-mono font-medium transition-all disabled:opacity-20 disabled:cursor-not-allowed"
                    style={{
                      background: "rgba(45,212,191,0.06)",
                      border: "1px solid rgba(45,212,191,0.1)",
                      color: "#4a8a7a",
                    }}
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />{" "}
                    Previous
                  </button>

                  <div
                    className="flex-1 text-center text-[10px] font-mono"
                    style={{ color: "#3a6a60" }}
                  >
                    {phase === 4 ? (
                      <span style={{ color: "#2dd4bf" }}>
                        ✓ All phases complete
                      </span>
                    ) : (
                      <>
                        Up next:{" "}
                        <span
                          style={{
                            color: PHASES[phase + 1].color,
                          }}
                        >
                          {PHASES[phase + 1].label}
                        </span>
                      </>
                    )}
                  </div>

                  <button
                    onClick={nextPhase}
                    disabled={phase === 4}
                    className="flex items-center gap-1.5 px-5 py-2 rounded-lg text-xs font-semibold transition-all active:scale-[.97] disabled:opacity-20 disabled:cursor-not-allowed"
                    style={
                      phase < 4
                        ? {
                            background: `linear-gradient(135deg,${PHASES[phase + 1].color},rgba(13,148,136,0.8))`,
                            color: "#04080e",
                            fontWeight: 700,
                            boxShadow: `0 4px 14px ${PHASES[phase + 1].glow}`,
                          }
                        : {
                            background: "rgba(45,212,191,0.06)",
                            border:
                              "1px solid rgba(45,212,191,0.1)",
                            color: "#3a6a60",
                          }
                    }
                  >
                    Next Phase{" "}
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Welcome / info panel */
            <div className="flex flex-col gap-4">
              {/* Ready card */}
              <div
                className="rounded-2xl flex flex-col items-center justify-center text-center gap-6 p-10"
                style={{
                  background: "rgba(45,212,191,0.03)",
                  border: "1px solid rgba(45,212,191,0.1)",
                  minHeight: 200,
                }}
              >
                <div className="relative">
                  <div
                    className="w-20 h-20 rounded-2xl flex items-center justify-center"
                    style={{
                      background:
                        "linear-gradient(135deg,rgba(13,148,136,0.18),rgba(96,165,250,0.12))",
                      border: "1px solid rgba(45,212,191,0.18)",
                      boxShadow:
                        "0 0 40px rgba(13,148,136,0.15)",
                    }}
                  >
                    <Terminal
                      className="w-9 h-9"
                      style={{ color: "rgba(45,212,191,0.6)" }}
                    />
                  </div>
                  <div
                    className="absolute -top-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center"
                    style={{
                      background: "rgba(45,212,191,0.15)",
                      border: "1px solid rgba(45,212,191,0.3)",
                    }}
                  >
                    <div
                      className="w-1.5 h-1.5 rounded-full animate-pulse"
                      style={{ background: "#2dd4bf" }}
                    />
                  </div>
                </div>
                <div>
                  <h3
                    style={{
                      fontFamily: "Rajdhani,sans-serif",
                      fontSize: 24,
                      fontWeight: 700,
                      color: "#d4f0e8",
                      marginBottom: 8,
                    }}
                  >
                    Ready to Analyze
                  </h3>
                  <p
                    className="text-sm leading-relaxed"
                    style={{
                      color: "#4a8a7a",
                      maxWidth: 280,
                      margin: "0 auto",
                    }}
                  >
                    Edit the code on the left and click{" "}
                    <span
                      style={{
                        color: "#2dd4bf",
                        fontFamily: "JetBrains Mono",
                        fontSize: 11,
                      }}
                    >
                      Analyze Code
                    </span>{" "}
                    to begin.
                  </p>
                </div>
              </div>

              {/* Phase preview cards */}
              <div className="grid grid-cols-1 gap-2">
                {PHASES.map((p) => {
                  const { Icon } = p;
                  return (
                    <div
                      key={p.id}
                      className="flex items-center gap-4 px-4 py-3 rounded-xl transition-all"
                      style={{
                        background: `rgba(${hexToRgb(p.color)},0.05)`,
                        border: `1px solid rgba(${hexToRgb(p.color)},0.12)`,
                      }}
                    >
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                        style={{
                          background: `rgba(${hexToRgb(p.color)},0.12)`,
                          boxShadow: `0 0 10px rgba(${hexToRgb(p.color)},0.15)`,
                        }}
                      >
                        <Icon
                          className="w-4 h-4"
                          style={{ color: p.color }}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div
                          className="text-sm font-semibold"
                          style={{ color: p.color }}
                        >
                          {p.label}
                        </div>
                        <div
                          className="text-[11px] truncate"
                          style={{ color: "#4a8a7a" }}
                        >
                          {
                            [
                              "Tokenize source into keywords, identifiers & literals",
                              "Validate grammar rules & syntax structure",
                              "Build hierarchical parse tree from grammar",
                              "Generate simplified three-address instructions",
                              "Apply constant folding & copy propagation",
                            ][
                              PHASES.findIndex(
                                (ph) => ph.id === p.id,
                              )
                            ]
                          }
                        </div>
                      </div>
                      <span
                        className="text-[10px] font-mono font-bold shrink-0"
                        style={{
                          color: `rgba(${hexToRgb(p.color)},0.4)`,
                        }}
                      >
                        {p.short}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* ════════════════════════════ FOOTER ════════════════════════════ */}
      <footer
        style={{
          borderTop: "1px solid rgba(45,212,191,0.08)",
          background: "rgba(4,8,14,0.6)",
          marginTop: 8,
        }}
      >
        <div className="max-w-[1400px] mx-auto px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className="w-6 h-6 rounded-md flex items-center justify-center"
              style={{
                background:
                  "linear-gradient(135deg,#0d9488,#fbbf24)",
              }}
            >
              <Terminal className="w-3 h-3 text-white" />
            </div>
            <div>
              <div
                className="text-[11px] font-semibold"
                style={{ color: "#4a8a7a" }}
              >
                Compiler Phases Demo
              </div>
              <div
                className="text-[10px] font-mono"
                style={{ color: "#2a4a42" }}
              >
                Interactive Educational Tool · CSE Compiler
                Design
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 flex-wrap justify-center">
            {PHASES.map((p, i) => (
              <span
                key={p.id}
                className="flex items-center gap-1"
              >
                {i > 0 && (
                  <span
                    style={{
                      color: "rgba(45,212,191,0.2)",
                      fontSize: 10,
                    }}
                  >
                    ›
                  </span>
                )}
                <span
                  className="text-[10px] font-mono transition-all"
                  style={{
                    color:
                      active && phase === i
                        ? p.color
                        : "#2a4a42",
                  }}
                >
                  {p.label}
                </span>
              </span>
            ))}
          </div>

          <div
            className="text-[10px] font-mono"
            style={{ color: "#2a4a42" }}
          >
            © 2024 · Built for Education
          </div>
        </div>
      </footer>
    </div>
  );
}

// hex to rgb helper for inline style interpolation
function hexToRgb(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `${r},${g},${b}`;
}