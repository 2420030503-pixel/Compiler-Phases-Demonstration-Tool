
  # Interactive Compiler Tool Website

  This is a code bundle for Interactive Compiler Tool Website. The original project is available at https://www.figma.com/design/r6mCj2e5T8FyWzkD5Y5jC1/Interactive-Compiler-Tool-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  